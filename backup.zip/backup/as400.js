<!--
var isMozilla = navigator.userAgent.indexOf('Mozilla') != -1 && parseInt(navigator.appVersion.substring(0,1)) >= 5;
var isIE = navigator.userAgent.indexOf('MSIE') != -1;
var isSafari = navigator.userAgent.indexOf('Safari') != -1;

function setCursorField(field) {
   document.DS5250.cursorfield.value = field.name;
}
   
function noHelp(){
return false;
}
function getKey(e) {
  k=document.all?window.event.keyCode:e.which;
  sk=document.all?window.event.shiftKey:e.shiftKey;
  ctl=document.all?window.event.ctrlKey:e.ctrlKey

	//alert(k);
  document.DS5250.TnKey.value = "";
  document.DS5250.PF.value = "";
  if (ctl) {document.DS5250.submit()}
  else {
  if (sk){

 	if(k==27) {
			document.DS5250.TnKey.Value = "SysReq";
	}
  	if (k > 111){
		document.DS5250.PF.value = "PF" + ((k-111) + 12) ;
	}
}  //SK
	else
	{
		if (k > 111){
	
			document.DS5250.PF.value = "PF" + (k-111) ;
		}
		else {
			if (k == 34){ 
				document.DS5250.TnKey.value = "PgDown";
			}
			if (k == 33){ 
				document.DS5250.TnKey.value = "PgUP";
			}
		} // PF key

	} // not SK
	// any keys caught?
 if ( (document.DS5250.TnKey.value != "") || (document.DS5250.PF.value != ""))
 {
 			 document.DS5250.submit();
  		//alert(document.DS5250.TnKey.value );
		//alert(document.DS5250.PF.value );
		//e.keyCode+=400;
		
		if (isIE){
			//alert("Internet Explorer");
			event.keyCode = 0;
            window.event.returnValue=false;
			}
        else if (isMozilla){
			//alert("Mozilla");
  			e.cancelBubble = true;
			return false;
			}

 } // not blank
} //ctrl key
}
//window.captureEvents(event.KEYPRESS);
document.onhelp=noHelp;
//document.onkeydown=getKey;

if (isMozilla) {
  document.addEventListener('keydown', getKey, true);
}
else if (isIE){
  document.onkeydown = getKey;
}

"//-->"