var net=require('net');
var client=net.connect(23, '10.11.7.129',function(){
console.log('connectedtoserver!');

//client.write("004660000001120210203C01000A80000200000000024217055608102309011237323232313736303030303039313036303630363036001652202020202020202020202020202020")

});
client.on('data',function(data){
console.log(data);
//client.end();
});
client.on('end',function(){
console.log('disconnectedfromserver');
});

