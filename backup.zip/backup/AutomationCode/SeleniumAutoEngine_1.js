const {
  Builder,
  By,
  until
} = require('..');

var driver = new Builder()
  .forBrowser('chrome')
  .build();

  /*var webdriver = require("selenium-webdriver"),
          By = webdriver.By,
          until = webdriver.until;

        var driver = new webdriver.Builder()
          .forBrowser('chrome')
          .usingServer('http://localhost:4444/wd/hub')
          .build();*/

//JSON input
/*var scriptDetails = {
  "scriptStep": [{
      "stepNo": 1,
      "stepId": "INB01",
      "fieldId": "FID1",
      "Step Description": "Enter the eBao URL",
      "Expected": "Login page opens up",
      "Actual": "",
      "Status": "",
      "fieldName": "",
      "fieldType": "URL",
      "keyword": "input",
      "xPath": "",
      "testData": "https://10.11.13.50/policycenter/"
    },
    {
      "stepNo": 2,
      "stepId": "INB02",
      "fieldId": "FID2",
      "Step Description": "Enter the user ID",
      "Expected": "User is able to enter the required user ID",
      "Actual": "",
      "Status": "",
      "fieldName": "tx_username",
      "fieldType": "textbox",
      "keyword": "input",
      "xPath": "2f2f2a5b4069643d22757365726e616d65225d",
      "testData": "ADMIN"
    },
    {
      "stepNo": 3,
      "stepId": "INB03",
      "fieldId": "FID3",
      "Step Description": "Enter the Password",
      "Expected": "User is able to enter the required password",
      "Actual": "",
      "Status": "",
      "fieldName": "tx_password",
      "fieldType": "textbox",
      "keyword": "input",
      "xPath": "2f2f2a5b4069643d2270617373776f7264225d",
      "testData": "eBao1234"
    },
    {
      "stepNo": 4,
      "stepId": "INB04",
      "fieldId": "FID4",
      "Step Description": "Click on the login button after entering the valid user ID and Password",
      "Expected": "Dashboard page opens up",
      "Actual": "",
      "Status": "",
      "fieldName": "bt_login",
      "fieldType": "button",
      "keyword": "input",
      "xPath": "2f2f2a5b4069643d22666d31225d2f73656374696f6e5b335d2f696e7075745b345d",
      "testData": ""
    },
    {
      "stepNo": 5,
      "stepId": "INB5",
      "fieldId": "FID4",
      "Step Description": "Click on the Query menu",
      "Expected": "",
      "Actual": "",
      "Status": "",
      "fieldName": "Query_menu",
      "fieldType": "button",
      "keyword": "input",
      "xPath": "2f2f2a5b4069643d225175657279225d",
      "testData": ""
    },
    {
      "stepNo": 6,
      "stepId": "INB06",
      "fieldId": "FID6",
      "Step Description": "Enter the policy number",
      "Expected": "should be able to enter the policy number",
      "Actual": "",
      "Status": "",
      "fieldName": "Policy Text",
      "fieldType": "textbox",
      "keyword": "input",
      "xPath": "2f2f2a5b4069643d227261696e626f772d75692d33225d",
      "testData": "PNPV2017-00020241"
    },
    {
      "stepNo": 7,
      "stepId": "INB7",
      "fieldId": "FID7",
      "Step Description": "Click on the search button",
      "Expected": "Dashboard page opens up",
      "Actual": "",
      "Status": "",
      "fieldName": "Search_button",
      "fieldType": "button",
      "keyword": "input",
      "xPath": "2f2f2a5b4069643d227261696e626f772d75692d34225d",
      "testData": ""
    },
    {
      "stepNo": 8,
      "stepId": "INB8",
      "fieldId": "FID8",
      "Step Description": "Table",
      "Expected": "table",
      "Actual": "",
      "Status": "",
      "fieldName": "table",
      "fieldType": "table",
      "keyword": "verify",
      "xPath": "2f2f2a5b4069643d227175657279526573756c745f74725f30225d",
      "testData": "PolicyNo:PNPee"
    },
  ]
};*/


  //Global variable declaration block---------------------------------------
var hexToString, x;
var testStatus, errDetails, screenShotPath;
var screenShotName, imagefilename;
var resultdatajson, recordnumber,actualresult;
var tramDetailsTemp = '{"projectSettings":[{"header":"Project ID","value":"Indusind"},{"header":"project Name","value":"Digital ACcount Opening"},{"header":"Testcase ID","value":"Digital Account Opening"},{"header":"Testcase Desc","value":"Digital Account Opening Through Tablet"},{"header":"Priority","value":"High"},{"header":"Mode","value":"Desktop"}],"stepDetails":[{"stepSettings":[{"header":"Step ID","value":"STEPIDDETAILS"},{"header":"Step Name","value":"STEPNAMEDETAILS"},{"header":"Step Descp","value":"STEPDESCDETAILS"},{"header":"Exp Result","value":"EXPECTEDRESULTDETAILS"},{"header":"Act Result","value":"ef"},{"header":"Status","value":"STATUSDETAILS"}],"images":["C:/Project_Name/User_name/16.12.16/bcd996d3-0e27-46f2-aa54-7b5f5881cb07.jpg"],"strUID":"H1IXSWGOg","fName":["IMAGEFILENAME.png"]}]}'

var DefectDetailsTemp = '{"overview":{"ov9":"DEFECTTYPE","ov8":"Major","ov5":"Medium","ov4":"DEFECTSUMMARY","tu1":"DEFECTDESC"},"comments":[{"text":"ddd","date":"Mon May 15 2017 21:52:25 GMT+0530 (India Standard Time)","corder":1}],"todo":[],"attachments":[{"_id": "594bc7b36ab2641ed0e7bbde","duplicate":true,"md5":"67b35bf088fbf0d85dc40f4334b008c3","metadata":{"user_id":1},"aliases":null,"uploadDate":"2017-05-12T06:11:53.081Z","chunkSize":261120,"length":169199,"contentType":"image/jpeg","filename":"DEFECTIMG.jpg"}]}'

async = require("async");
var fs = require('fs');
  //End of Global variable declaration block---------------------------------------


//=========================Start of main code block===============================

//Code to read JSON file--------------------------------------------------
    var rawdatafromfile = fs.readFileSync('eBoa_TestScript_Json.json');
    var scriptDetails = JSON.parse(rawdatafromfile);

    var stepdata = scriptDetails.scriptStep;
    jsonLen = scriptDetails.scriptStep.length;
    console.log("************no of records are:  " + jsonLen);
    //End of code to read JSON file-------------------------------------------



async.eachOfSeries(stepdata, function(value, key, callbackmain) {

  testStatus = "";
  errDetails = "";
  screenShotPath = "";
  recordnumber = key;
  browser = "chrome"

  stepIdVal = stepdata[key].stepId;
  stepDescriptionVal = stepdata[key].StepDescription;
  stepExpectedVal = stepdata[key].Expected;
  fieldIdVal = stepdata[key].fieldId;
  fieldNameVal = stepdata[key].fieldName;
  fieldReferenceVal = stepdata[key].fieldReference;
  fieldTypeVal = stepdata[key].fieldType;
  keywordVal = stepdata[key].keyword;
  tempXpathVal = stepdata[key].xPath_Hexa;
  //Tempnextfieldxpath = stepdata[key + 1].xPath
  testDataVal = stepdata[key].testData;

  console.log(stepIdVal + "  " + fieldIdVal + "  " + fieldNameVal + "  " + fieldTypeVal + "   " + keywordVal + "  " + testDataVal + "  " + tempXpathVal)

  if (fieldTypeVal != "URL") {
    //Calling function to convert Hexa value to String
    xPathVal = hextoStr(tempXpathVal);
    //Tempnextfieldxpathval = hextoStr(Tempnextfieldxpath);
  }

  keywordVal = keywordVal.toLowerCase();
  fieldTypeVal = fieldTypeVal.toLowerCase();

console.log("start of keyword switch ");
  switch (keywordVal) {
    case "input":
      switch (fieldTypeVal) {
        case "url":
        console.log("start of URL keyword ");
          driver.manage().window().maximize();    
          driver.get(testDataVal).then(function(resp) {
            testStatus = "Pass"
            errDetails = "";
            tramdetailssend(key);
            writeresultjson(testStatus, browser, errDetails,screenShotName)
            callbackmain();
          });
          break;


        case "link":
        setTimeout(function() {
                  return driver.findElement(By.xpath(xPathVal)).then(function(title) {
                    driver.findElement(By.xpath(xPathVal)).click();
                    testStatus = "Pass";
                    errDetails = "";
                    tramdetailssend(key);
                    writeresultjson(testStatus, browser, errDetails,screenShotName)
                    callbackmain();
                  });
                }, 1500);
                break;



        case "textbox":
          setTimeout(function() {
            driver.findElement(By.xpath(xPathVal)).sendKeys(testDataVal).then(function(resp) {
              driver.findElement(By.xpath(xPathVal)).click();
              testStatus = "Pass";
              errDetails = "";
              tramdetailssend(key);
              writeresultjson(testStatus, browser, errDetails,screenShotName)
              callbackmain();
            });
          }, 1000);
          break;

        case "button":

          setTimeout(function() {
            return driver.findElement(By.xpath(xPathVal)).then(function(title) {
              driver.findElement(By.xpath(xPathVal)).click();
              testStatus = "Pass";
              errDetails = "";
              tramdetailssend(key);
              writeresultjson(testStatus, browser, errDetails,screenShotName)
              callbackmain();
            });

          }, 10000);
          break;

        case "combobox":

          selectxpath = xPathVal;
          itemtoselect = testDataVal;
          var selectList, desiredOption, mainoptioncollect;
          var optioncollect;
          var textarr = [];
          var i = 0,
            x = 0;
          async.auto({
            get_selObj: function(callback) {
              driver.findElement(By.xpath(xPathVal))
              var selobjpromise = driver.findElement(By.xpath(selectxpath));
              callback(null, selobjpromise);
            },

            get_optionObj: ['get_selObj', function(results, callback) {
              executeScriptvalue = results.get_selObj;
              optionobjpromise = executeScriptvalue.then(function(ele) {
                driver.executeScript("return arguments[0].options", ele).then(function(optioncollect) {
                  optionobjcollect = optioncollect;
                  callback(null, optionobjcollect);
                })

              })
            }],


            get_desiredopt: ['get_optionObj', function(results, callback5) {

              optioncollect = results.get_optionObj;
              setTimeout(function() {
                optioncollect.some(function(option, funcallback) {
                  option.getText().then(function doesOptionMatch(text) {
                    console.log(itemtoselect + " item" + " -------text+-------" + text + "  ----- :")

                    if (itemtoselect == text) {
                      desiredOption = option;
                      callback5(null, desiredOption);

                    }
                  });
                })
              }, 1500)
            }],

            get_selectopt: ['get_desiredopt', function(results, callback) {
              desiredOption = results.get_desiredopt;
              console.log(desiredOption);
              if (desiredOption) {
                desiredOption.click();
              }
              testStatus = "Pass";
              errDetails = "";
              callback(null, "true");
            }],

            call_parent: ['get_selectopt', function(results, callback) {
              callback(null, "completed");
              callbackmain();
            }]

          });
          break;

        default:
          testStatus = "Fail";
          errDetails = "Field not found in the Webpage"
          break;
      }
      break;

    case "verify":
    console.log(fieldTypeVal);
    console.log(xPathVal);
      switch (fieldTypeVal) {
        case "text":
        console.log("inside text verify");
          setTimeout(function() {
            console.log("inside text verify settimeout");
            return driver.findElement(By.xpath(xPathVal)).then(function(textfield) {
              textfield.getText().then(function(fieldtext) {
                console.log("The test data is: "+ testDataVal + "  The data from the screen is "+ fieldtext);
                if (testDataVal == fieldtext) {
                  testStatus = "Pass";
                  errDetails = "";
                  errDetails = "The text " + "'" + fieldtext + "' " + "in the field matches the expected text " + testDataVal;;
                } else {
                  testStatus = "Fail";
                  errDetails = "The text " + "'" + fieldtext + "' " + "in the field does not match the expected text " + testDataVal;
                }
                tramdetailssend(key);
                writeresultjson(testStatus, browser, errDetails,screenShotName);
                callbackmain();
              });

            });

          }, 10000);
          break;

          case "table":
        setTimeout(function() {
                var tbl = driver.findElement(By.xpath(xPathVal));
                var tableattribute = tbl.getAttribute("value").then(function(attval){
                  console.log(attval);
                  var splitdata = testDataVal.split(":");
                  var attribute = splitdata[0];
                  var value = splitdata[1];


                  console.log("the test data aftersplit is: attribute: " + attribute + "   value: "+ value );
                  var tbljson = JSON.parse(attval);
                  console.log(tbljson);
                  console.log(splitdata[0]);
                  console.log(splitdata[1]);
                  console.log("the value fom the table tbljson[attribute] is " + tbljson[attribute]);

                  if(tbljson[attribute] == value) {
                    console.log("table pass");
                    testStatus = "Pass";
                    errDetails = "The value ' "+ tbljson[attribute] +"'  in the table column ' " + attribute + "' matches the expected value + '"+ "' "+ value ;

                    tramdetailssend(key);
                    writeresultjson(testStatus, browser, errDetails,screenShotName);
                    callbackmain();
                  }
                  else{
                    console.log("table fail");
                    testStatus = "Fail";
                    errDetails = "The value ' "+ tbljson[attribute] +"'  in the table column ' " + attribute + "' does not match the expected value + '"+ "' "+ value ;

                    tramdetailssend(key);
                    writeresultjson(testStatus, browser, errDetails,screenShotName);
                    callbackmain();
                  }
                  //return attval;
                });


                }, 1500);
                break;

        default:
          break;
      }
  }


})
//=========================End of main code block===============================


//==========================Generic function declaration block==================
//---------------------Tram Details-------------------------------------
    function tramdetailssend(key) {
      var imagefilename, tramDetails
      tramDetails = tramDetailsTemp.replace('STEPIDDETAILS', stepIdVal);
      tramDetails = tramDetails.replace('STEPNAMEDETAILS', stepIdVal);
      tramDetails = tramDetails.replace('STEPDESCDETAILS', stepDescriptionVal);
      tramDetails = tramDetails.replace('EXPECTEDRESULTDETAILS', stepExpectedVal);
      tramDetails = tramDetails.replace('STATUSDETAILS', testStatus);
      if (key == 0) {
        imagefilename = "s1-0";

      }
      if (key == 1) {
        imagefilename = "s1-1";

      }
      if (key > 1) {
        imagefilename = "s" + (key + 1) + "-" + 0;

      }
      tramDetails = tramDetails.replace('IMAGEFILENAME', imagefilename);
      tramfilepath = "C://Tristha//AQuA//current//server//uploads//AQuA//localhost//DAC//" + imagefilename + ".json"
      require('fs').writeFile(tramfilepath, tramDetails, function(err) {});
      //---------------------Screen shot start--------------------------------

      screenShotName = "C://Tristha//AQuA//current//server//uploads//AQuA//localhost//DAC//" + imagefilename + ".png"
      driver.takeScreenshot().then(function(image, err) {
        require('fs').writeFile(screenShotName, image, 'base64', function(err) {});


      });

    }
      //---------------------tram /Screen shot end----------------------------------------
//function to scroll the page and reach the field
function scrolltofield(elexpath) {
  var deferred = Q.defer()
  console.log(elexpath);
  var executeScriptvalue = driver.findElement(By.xpath(elexpath)).then(function(ele) {
    driver.executeScript("arguments[0].scrollIntoView(true); return arguments[0]", ele).then(function(data) {
      if (data == null) {
        deferred.reject(err);
      } else {
        deferred.resolve("done");
      }
    });
  });
}
//------------------------------------------------------------------------------
//----Function for Hexa value to String conversion----
function hextoStr(hex) {
  var str = '';
  for (var i = 0; i < hex.length; i += 2)
    str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
  return str;
}

//------------------------------------------------------------------------------
//Function for selecting from combo box
function selectOption(selectxpath, itemtoselect) {
  var selectList, desiredOption;
  var optioncollect;
  var executeScriptvalue = driver.findElement(By.xpath(selectxpath)).then(function(ele) {
    driver.executeScript("return arguments[0].options", ele).then(function(optioncollect) {
      optioncollect.some(function(option) {
        option.getText().then(function doesOptionMatch(text) {
          console.log(itemtoselect + " item" + " -------text+-------" + text + "  ----- :")
          if (itemtoselect == text) {
            desiredOption = option;
            i = 1;
            return true;
          }
        });
      });

    }).then(function clickOption() {
      if (desiredOption) {
        desiredOption.click();
        console.log("clicking the desired option")
      }
    });;

  });

}
//------------------------------------------------------------------------------
//----Function for writing result--------------------
function writeresultjson(status, browser, actualres,screenshot) {

      var datetime = new Date();
      //EDate = datetime.split("T");

      stepdata[recordnumber].Status = status;
      stepdata[recordnumber].Browser = browser;
      stepdata[recordnumber].ExecutionDate = datetime;
      stepdata[recordnumber].screenshot = screenshot;
      stepdata[recordnumber].Actual = actualres;
      //stepdata[recordnumber].SystemExecutedOn =

      resultdatajson = JSON.stringify(scriptDetails);
      fs.writeFileSync('FWD_Execution_Run2.json', resultdatajson);
}

//------------------------------------------------------------------------------
