var myapp = angular.module('mainApp', ['ngAnimate']);
myapp.directive('onReadFile', function ($parse) {
    return {
        restrict: 'A',
        scope: false,
        link: function(scope, element, attrs) {
 console.log(element)
            element.bind('change', function(e) {
      
                var onFileReadFn = $parse(attrs.onReadFile);
             
                var reader = new FileReader();
                
                reader.onload = function() {
                  console.log(reader)

                    var fileContents = reader.result;

                    // invoke parsed function on scope
                    // special syntax for passing in data
                    // to named parameters 
                    // in the parsed function
                    // we are providing a value for the property 'contents'
                    // in the scope we pass in to the function
                    scope.$apply(function() {
                        onFileReadFn(scope, {
                            'contents' : fileContents
                          
                        });
                    });
                };
                console.log(element[0].files[0],'ppppppppp')
                reader.readAsText(element[0].files[0]);

            });
        }
    };
})
myapp.controller('mainController',function($scope,$http){
      $scope.jsons=[];
      $scope.gjson=[];


        $scope.setFile = function(element) {
          
        $scope.$apply(function($scope) {
          
        $scope.getjson = function(ele) {
          var element=JSON.parse(ele);
          $scope.gjson.push(element);
          console.log("201", $scope.gjson)
          return $scope.gjson;
        }

            $scope.theFile = element.files[0];
                console.log($scope.theFile.name)
                
            $scope.file=$scope.theFile.name;
        
            
                   console.log($scope.file,'10');
$scope.jsons.push($scope.file);
                  console.log($scope.jsons,'16');


    });
          
       
    };

       









        $scope.openscreen=function(d)
        {
    $scope.screenshot= d;
        }


      /*---------------------------------------------------------------*/




$scope.sizefull="10";
$scope.sizetab=function() {

$scope.sizefull="col-md-10";

console.log($scope.sizefull);

        }
  $scope.sizetab1=function() {

$scope.sizefull="col-md-12";
console.log($scope.sizefull);

        }

        /*-------------------------------------------------------------*/
          $scope.displayFileContents = function(data,i) {
   
   data=$scope.gjson[i].scriptStep;
     
       console.log( data)


      $scope.contents=data;
      console.log( $scope.contents)
                    
                  
                                                                  
                                //console.log($scope.passedpa)
                               //console.log($scope.failedpa)
             var tatal="";
                    var passed=[];
                    var passedpa=[];
                    var failedpa=[];
                    var holdpa=[];
                                //console.log($scope.contents.length)
                                $scope.tatal=$scope.contents.length;

                                for(var i=0;i<$scope.contents.length;i++) {
 

                               // console.log($scope.contents[i].Status);
                               passed.push($scope.contents[i].Status);
                                

                                }
                                 $scope.passed =passed;


                               for(var x=0;x<$scope.passed.length;x++){

                                 if(($scope.passed[x]) === "Pass"){
                               
                                     passedpa.push(($scope.passed[x]))
                               }
                                 else if(($scope.passed[x]) === "Fail"){
                                    failedpa.push(($scope.passed[x]))
                                 }
                                 else if(($scope.passed[x]) === "hold"){
                                    holdpa.push(($scope.passed[x]))
                                 }
                                
                                }
                                $scope.passedpa=passedpa.length;
                                $scope.failedpa=failedpa.length;
                                $scope.holdpa=holdpa.length; 


    };


//$scope.contents = [{heading:"Content heading", description:"The actual content"}];
//Just a placeholder. All web content will be in this format
});