describe('AngularJS Test Engine', function() {

  //Global variable declaration block-------------------------------------------
  async = require("async");
  var testStatus, errDetails, screenShotPath;
  var screenShotName;
  var fieldObj;
  var fs = require('fs');

  //End of Global variable declaration block------------------------------------



  //---------Main execution block-------------------------------------------------

  it('Test suite execution', function() {
    browser.driver.manage().window().maximize();
    //  browser.waitForAngularEnabled(false);

    //  browser.get('https://www.fwd.com.sg/car-insurance/comprehensive-motor-insurance/online-quote/#/quotation/quickQuestions');
    browser.get('https://www.fwd.com.sg/life-insurance/enhanced-term-life-insurance/online-quote/#/quotation/quickQuestions');
    browser.waitForAngular();
    //browser.driver.sleep(7000);
    console.log("Before start of select option");
    //====================try1==================
    // element.all(by.css('md-select')).each(function(eachElement) {
    // eachElement.click(); //select the select
    // browser.driver.sleep(500); //wait for the renderings to take effect
    // element(by.css('md-option')).click //select the first md-option
    // browser.driver.sleep(500); //wait for the renderings to take effect
    // });
    //=====================end try1====================

    //====================try2=======================
    // var x = element.all(by.css('md-select')).get(4);
    //     console.log("====================================");
    //     browser.driver.sleep(7000);
    //     browser.executeScript("arguments[0].click();", x).then(function(ele){
    //         console.log(ele);
    //
    //     });
    //     console.log("====================================");

    //===================Input box=============================
    console.log("*********Inside Textbox switch************")
    var xPathVal = '//*[@id="formViews"]/div/div[1]/div/h5[1]/div[3]/span/input'
    var testDataVal = "01-01-1980"

    browser.waitForAngular();
    fieldObj = element.all(by.xpath(xPathVal)).get(0);
    fieldObj.clear().sendKeys(testDataVal).then(function(resp) {
      //browser.driver.sleep(5000);
      // testStatus = "Pass";
      // errDetails = "";
      // tramdetailssend(key)
      // callbackmain();
    });
    //This works for ddate filed that needs to be typed
    //=================end of input box success=========================
    //=================Combo Box======================================

    testDataVal = "Smoker";
    xpathval = '//*[@id="formViews"]/div/div[1]/div/h5[1]/div[2]';
    browser.waitForAngular();
    element(by.xpath(xpathval)).click().then(function(res) {
      browser.waitForAngular().then(function(res) {
        element.all(by.cssContainingText('div', testDataVal)).each(function(ele, index) {
          ele.getText().then(function(text) {
            if(text==testDataVal){
              ele.click();
              browser.waitForAngular();
              browser.actions().sendKeys(protractor.Key.ESCAPE).perform();
            }
          });

        })

      });

    });

    browser.driver.sleep(5000);
//=================End of Combo Box====================================

    //==============slider============================
    // browser.waitForAngular();

    // xpathval = '//*[@id="formViews"]/div/div[1]/div/div/div/div/div/md-slider';
    // testDataVal = "7500000";
    // browser.waitForAngular();
    // var sliderobj = element.all(by.xpath(xpathval)).get(0);
    // slidermaxvalue = sliderobj.getAttribute('aria-valuemin');
    // sliderminvalue = sliderobj.getAttribute('aria-valuemax');
    // var intsliderval = parseInt(testDataVal);
    // console.log("slidermaxvalue : "+ slidermaxvalue.getText());
    // console.log("sliderminvalue : "+ sliderminvalue);
    //
    // var slidetsetvalue = ((((slidermaxvalue - sliderminvalue)*1000)/intsliderval)*100);
    // var sliderpercentage = slidetsetvalue;
    // console.log(sliderpercentage);
    // browser.driver.sleep(5000);
  //  browser.executeScript("arguments[0].style.left = 10%", sliderobj).then(function(label){
    //      browser.waitForAngular();

    //});

    // var slider = element(by.xpath('//*[@id="formViews"]/div/div[1]/div/div/div/div/div/md-slider/div/div/div[2]/div[1]'));
    // // browser.driver.sleep(5000);
    // // console.log(slider);
    // //browser.actions().dragAndDrop(slider,{x:100, y:0}).perform();
    // browser.actions().mouseMove(slider, {x: 3000, y: 0});
    // // browser.waitForAngular();
    //
    // browser.driver.sleep(5000).then(function(res){
    // //  browser.driver.executeScript("arguments[0].setAttribute('aria-valuenow','1550')",slider );
    // });


    //============slider============================

    //=============Checkbox-=======================
    // element(by.xpath('//*[@id="bno"]')).click().then(function(res){
    //   element(by.xpath('//*[@id="ETL_GetQuotepage_Next_1"]')).click();
    //   browser.waitForAngular();
    // });
    //
    //
    //
    // var xPathVal = '//*[@id="appFormZero"]/div[2]/div/div[1]/div[1]/md-checkbox'
    // var testDataVal = "select"
    // element(by.xpath('//*[@id="formViews"]/div/div[1]/div/div/div/div/div/md-slider/div/div/div[2]/div[1]')).click();

    //==========End of checckbox=============
  });
});
//---------End of Main execution block------------------------------------------
