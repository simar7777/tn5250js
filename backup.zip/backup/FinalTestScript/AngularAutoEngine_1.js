describe('AngularJS Test Engine', function() {
      // JSON Test data---------------------------------------------------------
      /*var scriptDetails = {
        "scriptStep": [{
            "stepNo": 1,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.1",
            "fieldId": "SN001FID1",
            "stepDescription": "Navigate to the test site URL",
            "expected": "The website opens up",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "",
            "fieldType": "URL",
            "keyword": "input",
            "xPath_org": "",
            "testData": "https://www.fwd.com.sg",
            //"testData": "https://www.fwd.com.sg/car-insurance/comprehensive-motor-insurance/online-quote/#/quotation/quickQuestions",
            //"testData": "https://www.fwd.com.sg/car-insurance/comprehensive-motor-insurance/online-quote/#/quotation/enhancements",
            "xPath": ""
          },
          {
            "stepNo": 2,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.2",
            "fieldId": "SN001FID2",
            "stepDescription": "Click on the \"Get a Quote\" button",
            "expected": "Please select the product opens up",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "get a quote button",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "/html/body/div[1]/section[1]/div/div/div/div/div/div/button",
            "testData": "",
            "xPath": "2f68746d6c2f626f64792f6469765b315d2f73656374696f6e5b315d2f6469762f6469762f6469762f6469762f6469762f6469762f627574746f6e"
          },
          {
            "stepNo": 3,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.3",
            "fieldId": "SN001FID3",
            "stepDescription": "Click on the car insurance product",
            "expected": "online quote window for car insurance opens up",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "car insurance product button",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"productListModalWrapper\"]/div/div/div/ul/li[1]/div[3]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2270726f647563744c6973744d6f64616c57726170706572225d2f6469762f6469762f6469762f756c2f6c695b315d2f6469765b335d"
          },
          {
            "stepNo": 4,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.4",
            "fieldId": "SN001FID4",
            "stepDescription": "Select the \"Car make\" details from the dropdown",
            "expected": "Should be able to select the car make from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Care make",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"makeListModel\"]",
            "testData": "BMW",
            "xPath": "2f2f2a5b406e616d653d226d616b654c6973744d6f64656c225d"
          },
          {
            "stepNo": 5,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.5",
            "fieldId": "SN001FID5",
            "stepDescription": "Select the \"car model\" from the dropdown",
            "expected": "Should be able to select the car model from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Car model",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"carModel\"]",
            "testData": "220I COUPE",
            "xPath": "2f2f2a5b406e616d653d226361724d6f64656c225d"
          },
          {
            "stepNo": 6,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.6",
            "fieldId": "SN001FID6",
            "stepDescription": "Select the \"year of registration\" from the dropdown",
            "expected": "Should be able to select the year of registration from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Year of registration",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"madeYear\"]",
            "testData": "2012",
            "xPath": "666f726d446174612e6d61646559656172"
          },
          {
            "stepNo": 7,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.7",
            "fieldId": "SN001FID7",
            "stepDescription": "Select the \"Marital status\" from the dropdown",
            "expected": "Should be able to select the marital status from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Marital status",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"maritalStatus\"]",
            "testData": "Married",
            "xPath": "2f2f2a5b406e616d653d226d61726974616c537461747573225d"
          },
          {
            "stepNo": 8,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.8",
            "fieldId": "SN001FID8",
            "stepDescription": "Select the \"gender\" from the dropdown",
            "expected": "Should be able to select the gender from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Gender",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"sex\"]",
            "testData": "Female",
            "xPath": "2f2f2a5b406e616d653d22736578225d"
          },
          {
            "stepNo": 9,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.9",
            "fieldId": "SN001FID9",
            "stepDescription": "Select the \"born in year\" from the dropdown",
            "expected": "Should be able to select the year of birth from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Born in year",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"birthDate\"]",
            "testData": "1950",
            "xPath": "2f2f2a5b406e616d653d22626972746844617465225d"
          },
          {
            "stepNo": 10,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.10",
            "fieldId": "SN001FID10",
            "stepDescription": "Select the \"number of years of driving\" from the dropdown",
            "expected": "Should be able to select the no of years of driving from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "No of years driving",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"drivingYears\"]",
            "testData": "Two",
            "xPath": "2f2f2a5b406e616d653d2264726976696e675965617273225d"
          },
          {
            "stepNo": 11,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.11",
            "fieldId": "SN001FID11",
            "stepDescription": "Select the \"number of Claims made\" from the dropdown",
            "expected": "Should be able to select the no of claims made from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "No of claims",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"noOfClaims\"]",
            "testData": "3 or more",
            "xPath": "666f726d446174612e6e6f4f66436c61696d73"
          },
          {
            "stepNo": 12,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.12",
            "fieldId": "SN001FID12",
            "stepDescription": "Select the \"NCD%\" from the dropdown",
            "expected": "Should be able to select the NCD% from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "NCD%",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@name=\"claimsDiscount\"]",
            "testData": "10%",
            "xPath": "2f2f2a5b406e616d653d22636c61696d73446973636f756e74225d"
          },
          {
            "stepNo": 13,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.13",
            "fieldId": "SN001FID13",
            "stepDescription": "Select the \"Demerit points\" details from the dropdown",
            "expected": "Should be able to select the Demerit points from the dropdown",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Demerit points",
            "fieldType": "comboBox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"demeritFee\"]",
            "testData": "Not Demerit Points Free",
            "xPath": "2f2f2a5b406e616d653d2264656d65726974466565225d"
          },
          {
            "stepNo": 13.1,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.13.1",
            "fieldId": "SN001FID13.1",
            "stepDescription": "Click on the \"Skip\" button for the promo code",
            "expected": "Should skip the promo code",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "have a promo code?",
            "fieldType": "button",
            "keyword": "verify",
            "xPath_org": "//*[@id=\"CI_GetQuotepage_Promo_Skip\"]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2243495f47657451756f7465706167655f50726f6d6f5f536b6970225d"
          },
          {
            "stepNo": 14,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.14",
            "fieldId": "SN001FID14",
            "stepDescription": "Click on the \"Next\" button",
            "expected": "Should be able to click on the next button",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Next button",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"CI_GetQuotepage_Next_1\"]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2243495f47657451756f7465706167655f4e6578745f31225d"
          },
          {
            "stepNo": 15,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.15",
            "fieldId": "SN001FID15",
            "stepDescription": "Click on the \"Skip\" button for the promo code",
            "expected": "Should skip the promo code",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "have a promo code?",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"CI_GetQuotepage_Promo_Skip\"]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2243495f47657451756f7465706167655f50726f6d6f5f536b6970225d"
          },
          {
            "stepNo": 16,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.16",
            "fieldId": "SN001FID16",
            "stepDescription": "Click on the \"No, show me the quotes\" button for the discount question.",
            "expected": "should be able to clcik on the show me the quotes button and proceed.",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "No, show me the quotes button",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"CI_GetQuotepage_Discount_No\"]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2243495f47657451756f7465706167655f446973636f756e745f4e6f225d"
          },
          {
            "stepNo": 17,
            "scriptName": "Select insurance product and enter details for a quote",
            "scriptId": "SN001",
            "stepId": "SN001.17",
            "fieldId": "SN001FID17",
            "stepDescription": "Click on the \"Buy\" button under the classic premium option",
            "expected": "user should be able to select and buy the classic premium option",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "buy classic button",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"CI_QuoteSummarypage_Classic_Buy\"]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2243495f51756f746553756d6d617279706167655f436c61737369635f427579225d"
          },
          {
            "stepNo": 18,
            "scriptName": "Enter enhancement details",
            "scriptId": "SN002",
            "stepId": "SN002.1",
            "fieldId": "SN002FID1",
            "stepDescription": "Click on the \"Yes, continue\" button on the information confirmation screen to enter enhancement details",
            "expected": "user should be able to click on the \"yes, continue\" button",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Yes continue button",
            "fieldType": "link",
            "keyword": "input",
            "xPath_org": "//*[@id=\"CI_BuyEnhacements_Continue_Yes\"]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2243495f427579456e686163656d656e74735f436f6e74696e75655f596573225d"
          },
          {
            "stepNo": 19,
            "scriptName": "Enter enhancement details",
            "scriptId": "SN002",
            "stepId": "SN002.2",
            "fieldId": "SN002FID2",
            "stepDescription": "click on the next button on the enhancement screen",
            "expected": "User should be able to proceed without clicking on the enhancements",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "next button",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"CI_BuyEnhacements_Next_Submit\"]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2243495f427579456e686163656d656e74735f4e6578745f5375626d6974225d"
          },
          {
            "stepNo": 20,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.1",
            "fieldId": "SN003FID1",
            "stepDescription": "Enter the drive Full name (as on NRIC/FIN)",
            "expected": "Should be able to enter the driver name",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Driver Full name",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[1]/div[2]/input",
            "testData": "Dummy data for Test Automation PoC",
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b315d2f6469765b325d2f696e707574"
          },
          {
            "stepNo": 21,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.2",
            "fieldId": "SN003FID2",
            "stepDescription": "Enter the Preferred name\n(if you’d like to be addressed differently)",
            "expected": "should be able to enter the preffered name",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Driver Preferred name",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[2]/div[2]/input",
            "testData": "Pls Ignore this data",
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b325d2f6469765b325d2f696e707574"
          },
          {
            "stepNo": 22,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.3",
            "fieldId": "SN003FID3",
            "stepDescription": "Enter the driver email id",
            "expected": "should be able to enter the email id",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Driver email",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[3]/div[2]/input",
            "testData": "donotreply@gmail.com",
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b335d2f6469765b325d2f696e707574"
          },
          {
            "stepNo": 23,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.4",
            "fieldId": "SN003FID4",
            "stepDescription": "Enter the driver Mobile number",
            "expected": "should be able to enter the mobile number",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Driver mobile number",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[4]/div[2]/input",
            "testData": 87654321,
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b345d2f6469765b325d2f696e707574"
          },
          {
            "stepNo": 24,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.5",
            "fieldId": "SN003FID5",
            "stepDescription": "Enter the Date of birth",
            "expected": "should be able to enter the date of birth",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Date of birth",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[5]/div[2]/div/div/input",
            "testData": "01072017",
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b355d2f6469765b325d2f6469762f6469762f696e707574"
          },
          {
            "stepNo": 25,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.6",
            "fieldId": "SN003FID6",
            "stepDescription": "Enter the NRIC/FIN",
            "expected": "should be able to enter the NRIC/FIN details",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "NRIC_FIN",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[6]/div[2]/input",
            "testData": "S7572146C",
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b365d2f6469765b325d2f696e707574"
          },
          {
            "stepNo": 26,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.7",
            "fieldId": "SN003FID7",
            "stepDescription": "Enter the Postal code",
            "expected": "should be able to enter the Postal code",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Postal code",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[7]/div[2]/div/div[1]/input",
            "testData": 247964,
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b375d2f6469765b325d2f6469762f6469765b315d2f696e707574"
          },
          {
            "stepNo": 27,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.8",
            "fieldId": "SN003FID8",
            "stepDescription": "Click on the \"get address\" button",
            "expected": "should be able to click on the get address button after entering the postal code",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "get address button",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[7]/div[2]/div/div[2]/button",
            "testData": "",
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b375d2f6469765b325d2f6469762f6469765b325d2f627574746f6e"
          },
          {
            "stepNo": 28,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.9",
            "fieldId": "SN003FID9",
            "stepDescription": "Enter the unit details",
            "expected": "Should be able to enter the unit details",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Unit",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[9]/div[2]/input",
            "testData": 1,
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b395d2f6469765b325d2f696e707574"
          },
          {
            "stepNo": 29,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.10",
            "fieldId": "SN003FID10",
            "stepDescription": "Enter the \"Policy start date",
            "expected": "Should be able to enter the Policy start date",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Policy start date",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[10]/div[2]/div/div[1]/input",
            "testData": "01072017",
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b31305d2f6469765b325d2f6469762f6469765b315d2f696e707574"
          },
          {
            "stepNo": 30,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.11",
            "fieldId": "SN003FID11",
            "stepDescription": "Enter the \"Car plate number",
            "expected": "Should be able to enter the Car plate number",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Car plate number",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[11]/div[2]/input",
            "testData": "S0000X",
            "xPath": "2f2f2a5b4069643d226170706c69636174696f6e466f726d225d2f6469765b31315d2f6469765b325d2f696e707574"
          },
          {
            "stepNo": 31,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.12",
            "fieldId": "SN003FID12",
            "stepDescription": "Enter the \"Finance company",
            "expected": "Should be able to enter the Finance company name",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Finance company",
            "fieldType": "textbox",
            "keyword": "input",
            "xPath_org": "//*[@id=\"input-636\"]",
            "testData": "Sample company",
            "xPath": "2f2f2a5b4069643d22696e7075742d363336225d"
          },
          {
            "stepNo": 32,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.13",
            "fieldId": "SN003FID13",
            "stepDescription": "Click on the check button to give consent",
            "expected": "user should be able to give consent",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "Consent check box",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"applicationForm\"]/div[13]/div[1]/div[1]/md-checkbox/div[1]",
            "testData": "",
            "xPath": ""
          },
          {
            "stepNo": 33,
            "scriptName": "Enter the driver details",
            "scriptId": "SN003",
            "stepId": "SN003.14",
            "fieldId": "SN003FID14",
            "stepDescription": "Click on the \"Next\" button on the driver details screen",
            "expected": "user should be able to click on the next button",
            "Actual": "",
            "Status": "",
            "stid": "",
            "fieldName": "next button",
            "fieldType": "button",
            "keyword": "input",
            "xPath_org": "//*[@id=\"CI_Application_Next\"]",
            "testData": "",
            "xPath": "2f2f2a5b4069643d2243495f4170706c69636174696f6e5f4e657874225d"
          }
        ]
      };*/
      //End of JSON Test data---------------------------------------------------

      //Global variable declaration block---------------------------------------
      async = require("async");
      var fs = require('fs');

      var tramDetailsTemp = '{"projectSettings":[{"header":"Project ID","value":"Indusind"},{"header":"project Name","value":"Digital ACcount Opening"},{"header":"Testcase ID","value":"Digital Account Opening"},{"header":"Testcase Desc","value":"Digital Account Opening Through Tablet"},{"header":"Priority","value":"High"},{"header":"Mode","value":"Desktop"}],"stepDetails":[{"stepSettings":[{"header":"Step ID","value":"STEPIDDETAILS"},{"header":"Step Name","value":"STEPNAMEDETAILS"},{"header":"Step Descp","value":"STEPDESCDETAILS"},{"header":"Exp Result","value":"EXPECTEDRESULTDETAILS"},{"header":"Act Result","value":"ef"},{"header":"Status","value":"STATUSDETAILS"}],"images":["C:/Project_Name/User_name/16.12.16/bcd996d3-0e27-46f2-aa54-7b5f5881cb07.jpg"],"strUID":"H1IXSWGOg","fName":["IMAGEFILENAME.png"]}]}'

      var DefectDetailsTemp = '{"overview":{"ov9":"DEFECTTYPE","ov8":"Major","ov5":"Medium","ov4":"DEFECTSUMMARY","tu1":"DEFECTDESC"},"comments":[{"text":"ddd","date":"Mon May 15 2017 21:52:25 GMT+0530 (India Standard Time)","corder":1}],"todo":[],"attachments":[{"_id": "594bc7b36ab2641ed0e7bbde","duplicate":true,"md5":"67b35bf088fbf0d85dc40f4334b008c3","metadata":{"user_id":1},"aliases":null,"uploadDate":"2017-05-12T06:11:53.081Z","chunkSize":261120,"length":169199,"contentType":"image/jpeg","filename":"DEFECTIMG.jpg"}]}'

      var testStatus, errDetails, screenShotPath;
      var screenShotName;
      var fieldObj;
      //End of Global variable declaration block--------------------------------

      //Code to read JSON file--------------------------------------------------
      var rawdatafromfile = fs.readFileSync('LifeTerm_custPortal_TestScript_Json.json');
      var scriptDetails = JSON.parse(rawdatafromfile);

      var stepdata = scriptDetails.scriptStep;
      jsonLen = scriptDetails.scriptStep.length;
      console.log("************no of records are:  " + jsonLen);
      //End of code to read JSON file-------------------------------------------

      //----Function for Hexa value to String conversion----
      function hextoStr(hex) {
        var str = '';
        for (var i = 0; i < hex.length; i += 2)
          str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
        return str;
      }
      //----End of Function for Hexa value to String conversion----

      //function for taking screen shots--------------------------------------------
      //---------------------Tram Details-------------------------------------
      function tramdetailssend(key) {
        var imagefilename, tramDetails
        tramDetails = tramDetailsTemp.replace('STEPIDDETAILS', stepIdVal);
        tramDetails = tramDetails.replace('STEPNAMEDETAILS', stepIdVal);
        tramDetails = tramDetails.replace('STEPDESCDETAILS', stepDescriptionVal);
        tramDetails = tramDetails.replace('EXPECTEDRESULTDETAILS', stepExpectedVal);
        tramDetails = tramDetails.replace('STATUSDETAILS', testStatus);

        if (key == 0) {
          imagefilename = "s1-0";

        }
        if (key == 1) {
          imagefilename = "s1-1";

        }
        if (key > 1) {
          imagefilename = "s" + (key + 1) + "-" + 0;

        }
        tramDetails = tramDetails.replace('IMAGEFILENAME', imagefilename);
        tramfilepath = "C://Tristha//AQuA//current//server//uploads//AQuA//localhost//DAC//" + imagefilename + ".json"
        require('fs').writeFile(tramfilepath, tramDetails, function(err) {});
        //----------------Screen shot start------------------

        screenShotName = "C://Tristha//AQuA//current//server//uploads//AQuA//localhost//DAC//" + imagefilename + ".png"
        browser.takeScreenshot().then(function(image, err) {
          require('fs').writeFile(screenShotName, image, 'base64', function(err) {});
        });

        //--------------Code for logging defect----------------
        if (testStatus == "Fail") {

          Defectimagefilename = imagefilename + "_Defect";
          screenShotName1 = "C://Tristha//AQuA//current//server//uploads//AQuA//localhost//img//" + Defectimagefilename + ".jpg"
          browser.takeScreenshot().then(function(image, err) {
            require('fs').writeFile(screenShotName1, image, 'base64', function(err) {});

          });

          DefectDetails = DefectDetailsTemp.replace('DEFECTTYPE', "Major");
          DefectDetails = DefectDetails.replace('DEFECTSUMMARY', "Verification Failed");
          DefectDetails = DefectDetails.replace('DEFECTDESC', errDetails);
          DefectDetails = DefectDetails.replace('DEFECTIMG', stepIdVal);

          defectfilepath = "C://Tristha//AQuA//current//server//uploads//AQuA//localhost//defect//" + Defectimagefilename + ".json"
          require('fs').writeFile(defectfilepath, DefectDetails, function(err) {})

        }

      }
      //---------------------tram /Screen shot end------------------------------


      //----Function for writing result--------------------
      function writeresultjson(status, browser, actualres,screenshot) {

            var datetime = new Date();
            //EDate = datetime.split("T");

            stepdata[recordnumber].Status = status;
            stepdata[recordnumber].Browser = browser;
            stepdata[recordnumber].ExecutionDate = datetime;
            stepdata[recordnumber].screenshot = screenshot;
            stepdata[recordnumber].Actual = actualres;
            //stepdata[recordnumber].SystemExecutedOn =

            resultdatajson = JSON.stringify(scriptDetails);
            fs.writeFileSync('FWD_Execution_Run1.json', resultdatajson);
      }

      //------------------------------------------------------------------------------

      // End of function for taking screen shots--------------------------------
      it('Test suite execution', function() {
          browser.driver.manage().window().maximize();
          browser.waitForAngularEnabled(false);
          async.eachOfSeries(stepdata, function(value, key, callbackmain) {

              testStatus = "FAIL";
              errDetails = "";
              screenShotPath = "";

              stepIdVal = stepdata[key].stepId;
              fieldIdVal = stepdata[key].fieldId;
              stepDescriptionVal = stepdata[key].StepDescription;
              stepExpectedVal = stepdata[key].Expected;
              ActualVal = stepdata[key].Actual;
              StatusVal = stepdata[key].Status;
              ScreenNameVal = stepdata[key].ScreenName;
              fieldNameVal = stepdata[key].fieldName;
              fieldTypeVal = stepdata[key].fieldType;
              keywordVal = stepdata[key].keyword;
              tempXpathVal = stepdata[key].xPath_Hexa;
              testDataVal = stepdata[key].testData;


              keywordVal = keywordVal.toLowerCase();
              fieldTypeVal = fieldTypeVal.toLowerCase();
              console.log("fieldTypeVal: " + fieldTypeVal);
              if (fieldTypeVal != "url") {
                //Calling function to convert Hexa value to String
                xPathVal = hextoStr(tempXpathVal);
                //Tempnextfieldxpathval = hextoStr(Tempnextfieldxpath);
              }

              console.log(stepIdVal + "  " + fieldIdVal + "  " + fieldNameVal + "  " + fieldTypeVal + "   " + keywordVal + "  " + testDataVal + "  " + tempXpathVal)
              browser.executeScript("document.body.style.zoom='65%'");
              switch (keywordVal) {
                case "input":
                  switch (fieldTypeVal) {
                    case "url":
                      browser.get(testDataVal).then(function(resp) {
                        testStatus = "Pass"
                        errDetails = "";
                        tramdetailssend(key)
                        callbackmain();
                      });
                      break;

                    case "textbox":

                      console.log("*********Inside Textbox switch************")
                      fieldObj = element.all(by.xpath(xPathVal)).get(0);
                      fieldObj.clear().sendKeys(testDataVal).then(function(resp) {
                        testStatus = "Pass";
                        errDetails = "";
                        tramdetailssend(key)
                        callbackmain();
                      });
                      break;

                    case "button":
                      //  element(by.css('[href*="online-quote"]'))
                      fieldObj = element.all(by.xpath(xPathVal)).get(0);
                      browser.executeScript("document.body.style.zoom='65%'");
                      console.log("*********Inside button switch************")
                      //browser.sleep(2000);
                      browser.sleep(6000);
                      element(by.xpath(xPathVal)).isDisplayed().then(function(isVisible) {
                        console.log("checking for isdisplay");
                        if (isVisible) {
                          console.log(isVisible)
                          browser.executeScript("arguments[0].click();", fieldObj).then(function(resp) {
                            //browser.sleep(3000);
                            console.log("*********Inside button executescript************")
                            testStatus = "Pass";
                            errDetails = "";
                            tramdetailssend(key)
                            callbackmain();

                          });
                        } else {
                          console.log("*********Inside button not visible************")
                          browser.sleep(6000);
                          browser.executeScript('window.scrollTo(0,5000);').then(function() {


                            element(by.xpath(xPathVal)).isDisplayed().then(function(isVisible) {
                              if (isVisible) {
                                browser.executeScript("arguments[0].click();", fieldObj).then(function(resp) {
                                  testStatus = "Pass";
                                  errDetails = "";
                                  tramdetailssend(key)
                                  callbackmain();
                                });
                              }


                            })


                          });

                        }
                      });

                      break;


                    case "link":

                      element(by.buttonText('Yes, continue')).isDisplayed().then(function(isVisible) {
                        if (isVisible) {
                          var saveButton = element(by.buttonText('Yes, continue')).click().then(function() {
                            tramdetailssend(key)
                            callbackmain();

                          });
                        } else {
                          fieldObj = element.all(by.buttonText('Yes, continue')).get(0);
                          browser.executeScript("arguments[0].click();", fieldObj).then(function(resp) {
                            testStatus = "Pass";
                            errDetails = "";
                            tramdetailssend(key)
                            callbackmain();
                          });

                        }

                      })


                      break;

                    case "combobox":

                      browser.waitForAngular();
                      element(by.xpath(xPathVal)).click().then(function(res) {
                        browser.waitForAngular().then(function(res) {
                          element.all(by.cssContainingText('div', testDataVal)).each(function(ele, index) {
                            ele.getText().then(function(text) {
                              if (text == testDataVal) {
                                ele.click();
                                browser.waitForAngular();
                                browser.actions().sendKeys(protractor.Key.ESCAPE).perform();
                                testStatus = "Pass";
                                errDetails = "";
                                tramdetailssend(key)
                                callbackmain();
                              }
                            });

                          })

                        });

                      });

                      break;

                    default:
                      break;
                  }
                  break;

                case "verify":
                  browser.waitForAngular();
                  browser.driver.sleep(1000);
                  fieldObj = element.all(by.xpath(xPathVal)).get(0);
                  fieldObj.getAttribute('value').then(function(validatetext) {
                    console.log("validatetext: " + validatetext);
                    console.log("testDataVal: " + testDataVal);
                    if (validatetext == testDataVal) {
                      testStatus = "Pass";
                      errDetails = "";
                      //console.log("=========PASS==============");
                      tramdetailssend(key)
                      callbackmain();
                    } else {
                      //console.log("=========FAIL==============");
                      testStatus = "Fail";
                      errDetails = "Error: The actual value displayed in the field: '" + fieldNameVal + "' is '" + validatetext + "'" + " and it does not match the expected result " + testDataVal;
                      //console.log(errDetails);
                      tramdetailssend(key)
                      callbackmain();
                    }

                  });
                  break;


                case "isdisplayed":
                  element(by.xpath(xPathVal)).isDisplayed().then(function(isVisible) {
                    if (isVisible) {

                      testStatus = "Pass";
                      errDetails = "";
                      tramdetailssend(key)
                      callbackmain();

                    } else {
                      testStatus = "Fail";
                      errDetails = "Error: The field ' " + fieldNameVal + " is not getting displayed on the page";
                      tramdetailssend(key)
                      callbackmain();
                    }


                  })
                  break;

                default:
                  break;
              }

          });

      });

  });
