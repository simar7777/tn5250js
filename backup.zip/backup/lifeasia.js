var net = require('net');

var server = net.createServer(function(connection) { 
   console.log('client connected');
   
   
   
   connection.on('data', function(data) { 
   
	//console.log(data.length)
	
	//req= data.toString();
	
console.log(data)
	
	
	//var resp = schemereq(req)
	
	var resp_buf = Buffer.from("004C60000001120210203C01000E80000200000000024117004608101610011237323232313133303030303130313334303130303036303630363036001656202020202020202020202020202020" ,'hex')
	
	var res = connection.write(resp_buf);
	
	console.log(res)
	//console.log(req.substr(4,8))
	
	
	
   
   });
   
   connection.on('end', function() {
      console.log('client disconnected');
   });
  // connection.write('Hello World!\r\n');
   //connection.pipe(connection);
});
server.listen(1947, function() { 
   console.log('server is listening on 1947' );
});